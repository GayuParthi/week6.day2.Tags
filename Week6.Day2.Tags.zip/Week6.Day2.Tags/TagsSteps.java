package tagsstepdefinition;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TagsSteps {
	
	public ChromeDriver driver;
	public String text;
	
	@Given("Load the application url as {string}")
	public void load_the_application_url_as(String url) {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	
	}
	@Given("Enter the username as {string}")
	public void enter_the_username_as(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	@Given("Enter the password as {string}")
	public void enter_the_password_as(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	@When("Click on Login as {string}")
	public void click_on_login_as(String clickLogin) {
		driver.findElement(By.className(clickLogin)).click();
	    
	}
	@When("Click on Homepage as {string}")
	public void click_on_homepage_as(String clickhome) {
		driver.findElement(By.partialLinkText(clickhome)).click();
	    
	}
	@When("Click on Contacts Button")
	public void click_contacts() {
		driver.findElement(By.linkText("Contacts")).click();
	    
	}
	@When("Click on Create Contacts Button")
	public void click_create_contacts() {
		driver.findElement(By.linkText("Create Contact")).click();
	    
	    
	}
	@Given("Enter the First Name as {string}")
	public void first_name_as(String Fname) {
		driver.findElement(By.id("firstNameField")).sendKeys(Fname);
	    
	    
	}
	@Given("Enter the Last name as {string}")
	public void last_name_as(String Lname) {
		 driver.findElement(By.id("lastNameField")).sendKeys(Lname);
	    
	}
	@When("Click on Submit Button")
	public void click_submit() {
		driver.findElement(By.name("submitButton")).click();
	    
	    
	}
	@When("Find the Contact")
	public void find_contact() {
		text = driver.findElement(By.id("viewContact_firstName_sp")).getText();
	    
	    
	}
	@Then("Print the Name")
	public void print_name() {
		 System.out.println("First name = "+text+"   "+"Browser Title = "+driver.getTitle());
			System.out.println("Create Contact is completed..");
			driver.close();

}
	@When("Click on Leads Button to CreateLead")
	public void click_on_leads_button() {
		driver.findElement(By.linkText("Leads")).click();
	}
	@When("Click on create Lead Button to CreateLead")
	public void click_on_create_lead_button() {
		driver.findElement(By.linkText("Create Lead")).click();
	}
	@Given("Enter company name in CreateLead information")
	public void createLeadForm_companyName() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
	}
	@Given("Enter createLeadForm firstName as {string}")
	public void createLeadForm_firstName(String Fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(Fname);
	}
	@Given("Enter createLeadForm_lastName as {string}")
	public void createLeadForm_lastName(String Lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(Lname);
	}
	@Given("Enter createLeadForm_birthDate")
	public void createLeadForm_birthDate() {
		driver.findElement(By.id("createLeadForm_birthDate")).sendKeys("3/04/1999");
	}
	@Given("Enter createLeadForm_primaryPhoneAreaCode")
	public void createLeadForm_primaryPhoneAreaCode() {
		driver.findElement(By.id("createLeadForm_primaryPhoneAreaCode")).sendKeys("044");
	}
	@Given("Enter createLeadForm_primaryPhoneExtension")
	public void createLeadForm_primaryPhoneExtension() {
		driver.findElement(By.id("createLeadForm_primaryPhoneExtension")).sendKeys("22");
	}
	@Given("Enter createLeadForm_primaryEmail")
	public void enter_all_the_fields_in_create_lead_information() {
		driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys("babu@testleaf.com");
	}
	@Given("Enter createLeadForm_primaryPhoneNumber")
	public void createLeadForm_primaryPhoneNumber() {
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys("9457861236");
	}
	@Given("Enter createLeadForm_primaryPhoneAskForName")
	public void createLeadForm_primaryPhoneAskForName() {
		driver.findElement(By.id("createLeadForm_primaryPhoneAskForName")).sendKeys("Arith");
	}
	@Given("Enter createLeadForm_primaryWebUrl")
	public void createLeadForm_primaryWebUrl() {
		driver.findElement(By.id("createLeadForm_primaryWebUrl")).sendKeys("google.com");
	}
	@Given("Enter createLeadForm_generalToName")
	public void createLeadForm_generalToName() {
		driver.findElement(By.id("createLeadForm_generalToName")).sendKeys("Ashwin");
	}
	@Given("Enter createLeadForm_generalAttnName")
	public void createLeadForm_generalAttnName() {
		driver.findElement(By.id("createLeadForm_generalAttnName")).sendKeys("Alice");
	}
	@Given("Enter createLeadForm_generalAddress1")
	public void createLeadForm_generalAddress1() {
		driver.findElement(By.id("createLeadForm_generalAddress1")).sendKeys("123,ECR road");
	}
	@Given("Enter createLeadForm_generalAddress2")
	public void createLeadForm_generalAddress2() {
		driver.findElement(By.id("createLeadForm_generalAddress2")).sendKeys("TVK nagar");
	}
	@Given("Enter createLeadForm_generalCity")
	public void createLeadForm_generalCity() {
		driver.findElement(By.id("createLeadForm_generalCity")).sendKeys("Chennai");
	}
	@Given("Enter createLeadForm_generalStateProvinceGeoId")
	public void createLeadForm_generalStateProvinceGeoId() {
		driver.findElement(By.id("createLeadForm_generalStateProvinceGeoId")).sendKeys("Tennessee");
	}
	@Given("Enter createLeadForm_generalPostalCode")
	public void createLeadForm_generalPostalCode() {
		driver.findElement(By.id("createLeadForm_generalPostalCode")).sendKeys("640037");
	}
	@Given("Enter createLeadForm_generalPostalCodeExt")
	public void createLeadForm_generalPostalCodeExt() {
		driver.findElement(By.id("createLeadForm_generalPostalCodeExt")).sendKeys("05");
	}
	@Then("Click on create Lead ButtonSubmit")
	public void click_on_create_lead_button1() {
		driver.findElement(By.name("submitButton")).click();
	}
	@Then("Print the CreatedLead Name")
	public void print_createdLead_name() {
		 System.out.println("First name = "+text+"   "+"Browser Title = "+driver.getTitle());
			System.out.println("CreateLead is completed..");
			driver.close();

    }
	
	@When("Click on Leads Button to EditLead")
	public void click_on_leads_button_editLead() {
		driver.findElement(By.linkText("Leads")).click();
	}
	@When("Click on Find Leads Button to EditLead")
	public void click_on_Findleads_button() {
		driver.findElement(By.linkText("Find Leads")).click();
	}
	@Given("Enter the First Name in the Lead to EditLead")
	public void enter_firstname() {
		driver.findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys("Hari");
	}
	@When ("Click on current Find Leads Button to EditLead")
	public void click_currentFindLeads() {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
	}
	@When("Click on First LeadId to EditLead")
	public void click_firstLeadid() throws InterruptedException {
		driver.findElement(By.linkText("10127")).click();
		Thread.sleep(2000);
		System.out.println("The page title is  "+driver.getTitle());
	}
	@When("Click on Edit Button to EditLead")
	public void click_edit() {
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
	}
	@When("Clear the Update LeadForm CompanyName to EditLead")
	public void clear_updateLeadForm_companyName() {
		driver.findElement(By.id("updateLeadForm_companyName")).clear();
	}
	@Given("Update LeadForm CompanyName to EditLead")
	public void updateLeadForm_companyName() {
		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys("TestLeaf Training Centre");
	}
	@Then("Submit the form to EditLead")
	public void submit_the_form() {
		driver.findElement(By.xpath("(//input[@class='smallSubmit'])")).click();
	}
	@Then("Print the Edited Lead Name")
	public void print_editedLead_name() {
		 System.out.println("First name = "+text+"   "+"Browser Title = "+driver.getTitle());
			System.out.println("EditLead is completed..");
			driver.close();

    }
	
	@When("Click on Leads Button to DuplicateLead")
	public void click_on_LeadsButton_to_DuplicateLead() {
		driver.findElement(By.linkText("Leads")).click();
	}
	@When("Click on Find Leads Button to DuplicateLead")
	public void click_on_Findleads_button_to_DuplicateLead() {
		
		driver.findElement(By.linkText("Find Leads")).click();
	}
	@When("Click on Email to DuplicateLead")
	public void click_on_email_to_DuplicateLead() {
		driver.findElement(By.linkText("Email")).click();
	}
	@Given("Enter Email Address to DuplicateLead")
	public void enter_emailAddress_to_DuplicateLead() {
		driver.findElement(By.name("emailAddress")).sendKeys("hari@testleaf.com");
	}
	@When("Click on Find Leads to DuplicateLead")
	public void click_onFindLeads_to_DuplicateLead() throws InterruptedException {
		driver.findElement(By.xpath("//button[contains(text(), 'Find Leads')]")).click();
		Thread.sleep(1000);
	}
	@When("Click on First Lead to DuplicateLead")
	public void click_onfirstLead_to_DuplicateLead() {
		WebElement leadFirstName = driver.findElement(By.linkText("10568"));
		String capturedLeadName = leadFirstName.getText();
		System.out.println(capturedLeadName);
		leadFirstName.click();

	}
	@When("Click on Duplicate Lead")
	public void click_on_duplicateLead() {
		driver.findElement(By.linkText("Duplicate Lead")).click();
	}
	@When("Verify Duplicate Lead")
	public void verify_DuplicateLead() {
		if(driver.getTitle().contains("Duplicate Lead")) {
			System.out.println("The title contains the word Duplicate Lead");
		}else {
			System.out.println("The title does not contain the word Duplicate Lead");
		}
	}
	@When("Click on Submit to DuplicateLead")
	public void click_on_Submit_to_DuplicateLead() {
		driver.findElement(By.name("submitButton")).click();
	}
	@When("ViewLead FirstName in DuplicateLead")
	public void viewLead_FirstName() {
		String duplicatedLeadName = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println(duplicatedLeadName);
	}
	@When("Verify Captured LeadId in DuplicateLead")
	public void verify_Captured_LeadId() {
		
		Object duplicatedLeadName = null;
		Object capturedLeadName = null;
		if(capturedLeadName.equals(duplicatedLeadName)) {
	    	System.out.println("Duplicated lead name is same as Captured name");
	    }else {
	    	System.out.println("Duplicated lead name is not same as Captured name");
	    }
	}
	@Then("Print the DuplicateLead Name ")
	public void print_duplicatedLead_name() {
		 System.out.println("First name = "+text+"   "+"Browser Title = "+driver.getTitle());
			System.out.println("DuplicateLead is completed..");
			driver.close();

    }
	
	
}
